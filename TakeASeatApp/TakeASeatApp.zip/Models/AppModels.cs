﻿namespace TakeASeatApp.Models
{
	public static class App
	{
		public static bool IsInstalled { get; set; }
	}
}